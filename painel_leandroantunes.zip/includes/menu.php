<div class="left side-menu">
    <div class="topbar-left">
        <div class="">
            <!--<a href="index.html" class="logo text-center">Admiria</a>-->
            <a href="index.php" class="logo"><img src="assets/images/logofundo.png" height="90" alt="logo"></a>
        </div>
    </div>
    <div class="sidebar-inner slimscrollleft">
        <div style="background-color: #1e1e1e" id="sidebar-menu">
            <ul>
                <li style="padding-top: 30px;">
                    <a href="index.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Home </span>
                    </a>
                </li>


                <li style="color: #fff; font-size: 16px" class="menu-title">Blog</li>
                <li>
                    <a href="publicacoes.php" class="waves-effect"><i class="mdi mdi-calendar-check"></i><span>Publicações</span></a>
                </li>
                <li>
                    <a href="categorias.php" class="waves-effect"><i class="mdi mdi-clipboard-outline"></i><span>Categorias</span></a>
                </li>

                <li style="color: #fff; font-size: 16px" class="menu-title">Publicidade</li>
                <li>
                    <a href="anuncios.php" class="waves-effect"><i class="mdi mdi-chart-line"></i><span>Anúncios</span></a>
                </li>

                <li style="color: #fff; font-size: 16px" class="menu-title">Acesso</li>
                <li>
                    <a href="assinantes.php" class="waves-effect"><i
                                class="mdi mdi-google-maps"></i><span>Assinantes </span></a>
                </li>
                <li>
                    <a href="usuarios.php" class="waves-effect"><i
                                class="mdi mdi-account-location"></i><span>Usuários </span></a>
                </li>

                <li>
                    <a href="functions/sair.php">
                        <button style=" background-color:#fff; color: #263238; font-weight: bold; margin-top:10px; border-radius: 5px; height: 40px; width:100%; border: none">
                            Sair
                        </button>
                    </a>
                </li>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
