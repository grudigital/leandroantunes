<footer class="footer">
    © 2020 Leandro Antunes <span class="text-muted d-none d-sm-inline-block float-right">Desenvolvido com <i class="mdi mdi-heart text-danger"></i> por Wetrends</span>
</footer>